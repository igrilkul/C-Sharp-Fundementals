﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public interface IBirthable
    {
        string Birthdate { get; set; }
    }
}
