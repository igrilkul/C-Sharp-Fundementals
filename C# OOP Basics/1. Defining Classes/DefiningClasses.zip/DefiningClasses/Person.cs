﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    class Person
    {
        private string name;
        private int age;

        public Person(string Name,int Age)
        {
            this.name = Name;
            this.age = Age;
        }
    }
}
