﻿namespace TheTankGame.IO.Contracts
{
    public interface IWriter
    {
        void WriteLine(string output);
    }
}