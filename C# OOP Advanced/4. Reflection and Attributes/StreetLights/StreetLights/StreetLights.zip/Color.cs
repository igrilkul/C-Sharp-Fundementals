﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StreetLights
{
   public enum Color
    {
        Red,
        Green,
        Yellow
    }
}
