﻿using System;

namespace DatabaseExample
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
